package com.assignmentjava;

public class AA7 {

	static {
		System.out.println("SIB");
	}

	{
		System.out.println("IIB");
	}

	public AA7() {
		System.out.println("Constructor");
	}

	public static void main(String[] args) {
		AA7 sib1 = new AA7();
		System.out.println("-------------");
		AA7 sib2 = new AA7();

	}

}