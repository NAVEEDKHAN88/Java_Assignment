package com.assignmentjava;

public class AA6 {

	static {
		System.out.println("SIB");
	}

	{
		System.out.println("IIB");
	}

	 AA6() {
		System.out.println("Constructor");
	}

	public static void main(String[] args) {

		AA6 sib = new AA6();
	}

}