package com.assignmentjava;

public class AA8 {

	static {
		System.out.println("SIB-1");
	}

	static {
		System.out.println("SIB-2");
	}

	{
		System.out.println("IIB-1");
	}

	{
		System.out.println("IIB-2");
	}

	AA8() {
		System.out.println("Constructor");
	}

	public static void main(String[] args) {
		AA8 a = new AA8();

	}

}