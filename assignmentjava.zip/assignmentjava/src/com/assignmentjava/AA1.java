package com.assignmentjava;

public class  AA1{

	  int i;

	  // constructor with no parameter
	  private AA1() {
	    i = 5;
	    System.out.println("Constructor is called");
	  }

	  public static void main(String[] args) {

	    // calling the constructor without any parameter
	    AA1 obj = new AA1();
	    System.out.println("Value of i: " + obj.i);
	  }
	}