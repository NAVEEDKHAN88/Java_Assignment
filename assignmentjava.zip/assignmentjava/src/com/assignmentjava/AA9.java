package com.assignmentjava;

public class AA9 {
	int i,j,k;
	{
		i=10;
		j=20;
		k=30;
	}

	public static void main(String[] args) 
	{
		AA9 a1 = new AA9();
		System.out.println(a1.i);
		System.out.println(a1.j);
		System.out.println(a1.k);
	}
}

