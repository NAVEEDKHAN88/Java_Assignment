package com.assignmentjava;

public class AA {
	 String name;

	// constructor
	  AA() {
	    System.out.println("Constructor Called:");
	    name = "AA()";
	  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AA j=new AA();
		
		System.out.println("the constructor is:"+j.name);
		
	}

}
