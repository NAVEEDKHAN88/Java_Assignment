package com.assignmentjava;

public class AA2 {
	
	String name;
	// constroctor
	
	AA2(){
		 name="innoovatum";
		 System.out.println("institue is called");
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AA2 obj=new AA2();
		
		System.out.println(obj.name);

	}

}
