package com.assignmentjava;
// OBJECT IS NOT CREATED THERE FOR IIB AND CONSTRUCTOR ARE SKIPED
 
public class AA4 {
	static {// 5 3 100
		System.out.println(5);
	}
	{
		System.out.println(10);
	}

	AA4() {
		System.out.println(1000);
	}

	static {
		System.out.println(3);
	}
	{
		System.out.println(7);
	}

	public static void main(String[] args) {
		System.out.println(100);
	}
}
