package com.assignmentjava;

public class AA3 {
	static {
		System.out.println("sib 1");
	}
	{
		System.out.println("IIB1");
	}

	AA3() {
		System.out.println("THIS IS CONSTRUCTOR");
	}

	static {
		System.out.println("SIB-2");
	}
	{
		System.out.println("IIB-2");
	}

	public static void main(String[] args) {
		System.out.println("THIS IS MAIN");
		AA3 a1 = new AA3();
	}
}
