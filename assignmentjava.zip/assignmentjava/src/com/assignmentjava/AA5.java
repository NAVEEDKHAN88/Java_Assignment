package com.assignmentjava;

public class AA5 {
	static {
		System.out.println(5);
	}
	static {
		System.out.println(21);
	}
	static {
		System.out.println(30);
	}

	public static void main(String[] args) {
		System.out.println(100);
	}
}